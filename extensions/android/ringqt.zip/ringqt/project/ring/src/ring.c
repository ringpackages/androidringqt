/* Copyright (c) 2013-2022 Mahmoud Fayed <msfclipper@yahoo.com> */
#include "ring.h"

int main ( int argc, char *argv[] )
{
    ring_state_main(argc,argv);
    return 0 ;
}
