/* Copyright (c) 2013-2025 Mahmoud Fayed <msfclipper@yahoo.com> */

#include "ring.h"

int main(int nArgc, char *pArgv[]) {
	ring_state_main(nArgc, pArgv);
	return RING_EXIT_OK;
}
