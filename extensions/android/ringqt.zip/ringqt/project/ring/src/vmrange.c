/* Copyright (c) 2013-2026 Mahmoud Fayed <msfclipper@yahoo.com> */

#include "ring.h"

void ring_vm_stackdup(VM *pVM) {
	String *pString;
	double nNum1;
	void *pPointer;
	int nType;
	if (RING_VM_STACK_ISSTRING) {
		pString = ring_string_new2_gc(pVM->pRingState, RING_VM_STACK_READC, RING_VM_STACK_STRINGSIZE);
		RING_VM_STACK_PUSHCVALUE2(ring_string_get(pString), ring_string_size(pString));
		ring_string_delete_gc(pVM->pRingState, pString);
	} else if (RING_VM_STACK_ISNUMBER) {
		nNum1 = RING_VM_STACK_READN;
		RING_VM_STACK_PUSHNVALUE(nNum1);
	} else if (RING_VM_STACK_ISPOINTER) {
		pPointer = RING_VM_STACK_READP;
		nType = RING_VM_STACK_OBJTYPE;
		RING_VM_STACK_PUSHPVALUE(pPointer);
		RING_VM_STACK_OBJTYPE = nType;
		if (nType == RING_OBJTYPE_VARIABLE) {
			/* Support Calling the Getter Method */
			if ((RING_VM_IR_READI == RING_ONE) && (pVM->nVarScope == RING_VARSCOPE_OBJSTATE) &&
			    (ring_vm_oop_callmethodinsideclass(pVM) == 0)) {
				/* When using braces to access the object attribute */
				ring_vm_oop_setget(pVM, (List *)pPointer);
			} else if (RING_VM_IR_READI == RING_PARSER_ICG_USESETPROPERTY) {
				/* When using the dot operator to access the object attribute */
				pVM->lGetSetProperty = 1;
				ring_vm_oop_setget(pVM, (List *)pPointer);
				pVM->lGetSetProperty = 0;
			}
		}
	}
}

void ring_vm_range(VM *pVM) {
	double nNum1, nNum2;
	int x, nSize1, nSize2;
	char cStr[RING_CHARBUF];
	List *pVar;
	if (RING_VM_STACK_ISNUMBER) {
		nNum1 = RING_VM_STACK_READN;
		RING_VM_STACK_POP;
		if (RING_VM_STACK_ISNUMBER) {
			nNum2 = RING_VM_STACK_READN;
			RING_VM_STACK_POP;
			/* Create List Variable */
			pVar = ring_vm_rangenewlist(pVM);
			ring_list_enablecopybyref_gc(pVM->pRingState, pVar);
			/* Create List */
			if (nNum2 <= nNum1) {
				for (x = nNum2; x <= nNum1; x++) {
					ring_list_adddouble_gc(pVM->pRingState, pVar, x);
				}
			} else {
				for (x = nNum2; x >= nNum1; x--) {
					ring_list_adddouble_gc(pVM->pRingState, pVar, x);
				}
			}
		}
	} else if (RING_VM_STACK_ISSTRING) {
		nSize1 = RING_VM_STACK_STRINGSIZE;
		if (nSize1 == 1) {
			nNum1 = RING_VM_STACK_READC[0];
		}
		RING_VM_STACK_POP;
		if (nSize1 == 1) {
			if (RING_VM_STACK_ISSTRING) {
				nSize2 = RING_VM_STACK_STRINGSIZE;
				if (nSize2 == 1) {
					nNum2 = RING_VM_STACK_READC[0];
				}
				RING_VM_STACK_POP;
				if (nSize2 == 1) {
					cStr[1] = '\0';
					/* Create List Variable */
					pVar = ring_vm_rangenewlist(pVM);
					ring_list_enablecopybyref_gc(pVM->pRingState, pVar);
					/* Create List */
					if (nNum2 <= nNum1) {
						for (x = nNum2; x <= nNum1; x++) {
							cStr[0] = (char)x;
							ring_list_addstring_gc(pVM->pRingState, pVar, cStr);
						}
					} else {
						for (x = nNum2; x >= nNum1; x--) {
							cStr[0] = (char)x;
							ring_list_addstring_gc(pVM->pRingState, pVar, cStr);
						}
					}
				}
			}
		}
	}
}

List *ring_vm_rangenewlist(VM *pVM) {
	List *pVar;
	/* Create List Variable */
	ring_vm_createtemplist(pVM);
	pVar = (List *)RING_VM_STACK_READP;
	RING_VAR_SETTYPE(pVar, RING_VM_LIST);
	RING_VAR_SETLIST_GC(pVM->pRingState, pVar);
	ring_list_deleteallitems_gc(pVM->pRingState, RING_VAR_GETLIST(pVar));
	pVar = RING_VAR_GETLIST(pVar);
	return pVar;
}
