/* Copyright (c) 2019 Mahmoud Fayed <msfclipper@yahoo.com> */

#ifndef RINGQT_H
#define RINGQT_H

#define RINGQT_EVENT_SIZE 256
#define RINGQT_EVENT_SIZE_ERROR "The Event Code is larger than the allowed size!"

#endif 